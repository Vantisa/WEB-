import os

from flask import Flask, render_template, redirect, session, url_for, request
from flask_login import login_user, LoginManager, login_required, logout_user

from data import db_session
from data.books import Books
from data.login import LoginForm
from data.register import RegisterForm
from data.users import User


app = Flask(__name__)

login_manager = LoginManager()
login_manager.init_app(app)

SECRET_KEY = os.urandom(32)
app.config['SECRET_KEY'] = SECRET_KEY


IMG_DIR = '../static/img/'


def get_image_paths(products):
    """ Получает пути до изображений товаров """
    image_paths = {}
    for p in products:
        if p.photo_name is not None:
            image_paths[p.id] = os.path.join(IMG_DIR, p.photo_name)
    return image_paths


@login_manager.user_loader
def load_user(user_id):
    sess = db_session.create_session()
    return sess.query(User).get(user_id)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect("/")


@app.route('/back')
@login_required
def go_back():
    return redirect("/")


@app.route('/order/back')
@login_required
def go_back_after_order():
    return redirect("/")


@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        if form.password.data != form.password_again.data:
            return render_template('register.html', title='Регистрация', form=form,
                                   message="Пароли не совпадают")

        db_sess = db_session.create_session()
        if db_sess.query(User).filter(User.email == form.email.data).first():
            return render_template('register.html', title='Регистрация', form=form,
                                   message="Пользователь уже зарегистрирован")
        user = User(
            surname=form.surname.data,
            name=form.name.data,
            email=form.email.data,
        )
        user.set_password(form.password.data)
        db_sess.add(user)
        db_sess.commit()
        return redirect('/login')
    return render_template('register.html', title='Регистрация', form=form)


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        user = db_sess.query(User).filter(
            User.email == form.email.data).first()

        if not user:
            return render_template('login.html', message="Вы еще не зарегистрированы", form=form)

        if user.check_password(form.password.data):
            login_user(user, remember=form.remember_me.data)
            return redirect("/")
        return render_template('login.html', message="Неправильно введён логин или пароль", form=form)
    return render_template('login.html', title='Авторизация', form=form)


@app.route('/')
def index():
    db_sess = db_session.create_session()
    products = db_sess.query(Books).order_by(Books.date).all()

    if 'cart' not in session:
        session['cart'] = []
    return render_template("index.html", cart=session['cart'], books=products, image_paths=get_image_paths(products))


@app.route("/show_book/<int:product_id>")
def show_book(product_id):
    db_sess = db_session.create_session()
    product = db_sess.query(Books).get(product_id)

    image_path = None
    if product.photo_name is not None:
        image_path = os.path.join(IMG_DIR, product.photo_name)
    return render_template("show_book.html", cart=session['cart'], product=product, image_path=image_path)


@app.route("/add_book/<int:product_id>")
@app.route("/add_book/<int:product_id>/buy", endpoint='buy')
def add_to_cart(product_id):
    db_sess = db_session.create_session()
    product = db_sess.query(Books).get(product_id)

    if 'cart' not in session:
        session['cart'] = []  # хранить в сессии информацию о выбранных товарах

    cart_list = session['cart']
    cart_list.append(product.id)  # запомнить выбранный товар
    session['cart'] = cart_list
    session.modified = True

    product.nrof_products = max(0, product.nrof_products - 1)
    db_sess.add(product)  # обновить базу данных
    db_sess.commit()
    if request.endpoint == 'buy':
        return redirect(url_for('show_book', product_id=product_id))
    return render_template('product_added.html', cart=session['cart'])


@app.route('/cart')
@login_required
def show_payment_page():
    cart = []
    total_price = 0
    image_paths = {}
    unique_products = {}

    if 'cart' in session:
        db_sess = db_session.create_session()

        for product_id in session['cart']:
            product = db_sess.query(Books).get(product_id)
            total_price += product.price

            if unique_products.get(product_id) is not None:
                unique_products[product_id] += 1
            else:
                unique_products[product_id] = 1
                cart.append(product)

                if product.photo_name is not None:
                    image_path = os.path.join(IMG_DIR, product.photo_name)
                    image_paths[product_id] = image_path
    return render_template('cart.html', cart=cart, unique_products=unique_products, total_price=round(total_price, 1),
                           image_paths=image_paths)


@app.route("/cart/<int:product_id>/del", methods=['GET', 'POST'])
@login_required
def delete_from_cart(product_id):
    db_sess = db_session.create_session()
    product = db_sess.query(Books).get(product_id)

    if 'cart' in session:
        cart_list = session['cart']
        cart_list.remove(product.id)
        session['cart'] = cart_list
        session.modified = True

        product.nrof_products += 1
        db_sess.add(product)
        db_sess.commit()
    return redirect(url_for('show_payment_page'))


@app.route("/order")
@login_required
def make_order():
    session['cart'].clear()
    session['cart'] = []
    return render_template('order.html', cart=session['cart'])


def main():
    db_session.global_init("db/book_shop.sqlite")

    app.run(port=8000, host='127.0.0.1')


if __name__ == '__main__':
    main()
