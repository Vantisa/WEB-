from flask_restful import reqparse

parser = reqparse.RequestParser()
parser.add_argument('name', required=True)
parser.add_argument('author', required=True)
parser.add_argument('genre', required=True)
parser.add_argument('publishing_house', required=True)
parser.add_argument('year', required=True)
parser.add_argument('pages', required=True)
parser.add_argument('age_limit', required=True)
parser.add_argument('price', required=True)
parser.add_argument('nrof_products', required=True)
parser.add_argument('description', required=True)
parser.add_argument('photo_name', required=False)