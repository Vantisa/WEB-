import datetime

import sqlalchemy as sa
from sqlalchemy_serializer import SerializerMixin

from .db_session import SqlAlchemyBase


class Books(SqlAlchemyBase, SerializerMixin):
    __tablename__ = 'books'

    id = sa.Column(sa.Integer, primary_key=True, autoincrement=True)
    name = sa.Column(sa.String, nullable=False)
    author = sa.Column(sa.String, nullable=False)
    genre = sa.Column(sa.String, nullable=False)

    publishing_house = sa.Column(sa.String, nullable=False)
    year = sa.Column(sa.Integer, nullable=False)
    pages = sa.Column(sa.Integer, nullable=True)
    age_limit = sa.Column(sa.Integer, nullable=False)

    price = sa.Column(sa.Float, nullable=False)
    nrof_products = sa.Column(sa.Integer, nullable=False)
    date = sa.Column(sa.DateTime, default=datetime.datetime.now)

    description = sa.Column(sa.String, nullable=False)
    photo_name = sa.Column(sa.String, nullable=True)

    def __repr__(self):
        return f'<Книга> {self.name} {self.author}'